// AdminContext.js
import { createContext } from 'react';

const AdminContext = createContext({ isAdmin: false });

export default AdminContext;